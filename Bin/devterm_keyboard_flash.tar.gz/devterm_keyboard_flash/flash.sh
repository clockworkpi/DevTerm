#!/bin/bash

sudo  ./maple_upload ttyACM0 2 1EAF:0003  devterm_keyboard.ino.bin
